# 🌾 AgroVision AI – Smart Agriculture Assistant Backend

**IIT-Level CSE Final Year Capstone Project**  
A production-grade backend empowering Indian farmers with AI, real-time weather, voice chatbot, IoT simulation, disease detection, government schemes, and marketplace.

---

## 🚀 Quick Start

```bash
# 1. Clone/unzip the project
cd agrovision-backend

# 2. Install dependencies
npm install

# 3. Configure environment
cp .env.example .env
# Edit .env with your MongoDB URI and OpenWeatherMap API key

# 4. Seed government schemes (optional but recommended)
node seeds/schemeSeeder.js

# 5. Start server
npm start

# Development mode with hot reload
npm run dev
```

Server starts at: **http://localhost:5000**  
Health check: **GET http://localhost:5000/api/health**

---

## 📁 Project Structure

```
agrovision-backend/
├── server.js               ← Main entry point
├── .env.example            ← Environment template
├── config/                 ← DB + app config
├── models/                 ← 11 MongoDB models
├── routes/                 ← 12 route files
├── controllers/            ← 9 controller files
├── middleware/             ← Auth, roles, rate limit, error handler
├── utils/                  ← Weather, prediction ML, chatbot, reports, cron
├── sockets/                ← Socket.io JWT manager
├── seeds/                  ← DB seed scripts
└── uploads/                ← Images + Voice MP3 files
```

---

## 🔑 Environment Variables

```env
MONGO_URI=mongodb://localhost:27017/agrovision
JWT_SECRET=your_super_secret_jwt_key_min_32_chars
JWT_REFRESH_SECRET=your_refresh_secret_min_32_chars
OPENWEATHER_API_KEY=your_openweathermap_api_key   # Get free at openweathermap.org
CLIENT_URL=http://localhost:3000
RAZORPAY_KEY_ID=rzp_test_your_key
RAZORPAY_KEY_SECRET=your_razorpay_secret
PORT=5000
```

---

## 📡 API Reference

### Authentication
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Register farmer/buyer/admin |
| POST | `/api/auth/login` | Login → JWT tokens |
| POST | `/api/auth/logout` | Blacklist token |
| POST | `/api/auth/refresh` | Refresh access token |
| POST | `/api/auth/forgot-password` | Request reset link |
| POST | `/api/auth/reset-password/:token` | Reset password |
| GET | `/api/auth/me` | Get current user |

### 🌤️ Weather (Hyper-Detailed Multi-Timeframe)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/weather/24hour/:district` | 24 hourly slots + alerts |
| GET | `/api/weather/daily/:district` | 7-day forecast + sowing advice |
| GET | `/api/weather/weekly/:district` | Weekly summary + best spray days |
| GET | `/api/weather/monthly/:district` | 30-day outlook + sowing window |
| GET | `/api/weather/historical/:district?month=3` | 3 years historical data |
| GET | `/api/weather/alerts/:district` | Critical weather alerts |

**Test 24h weather:**
```bash
curl -H "Authorization: Bearer YOUR_TOKEN" \
  http://localhost:5000/api/weather/24hour/Pune
```

**Test monthly outlook:**
```bash
curl -H "Authorization: Bearer YOUR_TOKEN" \
  http://localhost:5000/api/weather/monthly/Nashik
```

### 🌾 Crop AI
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/crop/predict` | AI crop recommendation |
| GET | `/api/crop/predictions` | List all predictions |
| GET | `/api/crop/predictions/:id` | Single prediction |

**Predict crop:**
```json
POST /api/crop/predict
{
  "soilType": "black",
  "season": "kharif",
  "rainfall": 450,
  "temperature": 28,
  "humidity": 70
}
```

### 🔬 Disease Detection
```
POST /api/disease/detect    (multipart/form-data: image + cropName)
GET  /api/disease/reports
PATCH /api/disease/reports/:id/resolve
```

### 🤖 AI Voice Chatbot
```
POST /api/chatbot/ask       → { message, language: "hi"|"en" }
GET  /api/chatbot/history
DELETE /api/chatbot/history
```

**Test chatbot (Hindi):**
```json
POST /api/chatbot/ask
{
  "message": "Aaj baarish hogi kya?",
  "language": "hi"
}
```
Returns: `{ response: "...", voiceUrl: "/uploads/voice/voice_xxx.mp3", intent: "weather" }`

### 🏪 Marketplace
```
GET  /api/market/listings?crop=wheat&district=Pune
POST /api/market/listings
POST /api/market/listings/:id/bid
POST /api/market/order
GET  /api/market/price/:crop
```

### 💧 IoT Simulation
```
POST /api/sensor/simulate    → Sends fake sensor data, triggers irrigation logic
GET  /api/sensor/history
GET  /api/irrigation/schedule
```

**Simulate low moisture alert:**
```json
POST /api/sensor/simulate
{ "soilMoisture": 15, "temperature": 32, "humidity": 60 }
```

### 📊 Analytics
```
GET /api/analytics/farmer   → Yield trend, profit graph, risk reduction
GET /api/analytics/admin    → Platform stats (admin only)
```

### 📄 PDF Reports
```
GET /api/reports/generate?type=yield|profit|disease|full
GET /api/reports
```

---

## 🔌 Socket.io Testing

Connect with JWT auth token:

```javascript
const io = require("socket.io-client");

const socket = io("http://localhost:5000", {
  auth: { token: "YOUR_JWT_ACCESS_TOKEN" }
});

// Listen for connection
socket.on("connected", (data) => console.log(data.message));

// Send chat message (Hindi)
socket.emit("chatMessage", {
  message: "Mera wheat ka profit kitna hoga?",
  language: "hi"
});

// Receive response with voice URL
socket.on("chatResponse", (data) => {
  console.log("AI Reply:", data.message);
  console.log("Voice MP3:", data.voiceUrl);   // Play at localhost:5000/uploads/voice/xxx.mp3
  console.log("Intent:", data.intent);
});

// Simulate IoT sensor
socket.emit("sensorUpdate", {
  soilMoisture: 18,
  temperature: 34,
  humidity: 65
});

// Receive irrigation alert
socket.on("newNotification", (notif) => console.log("Alert:", notif));

// Join district room for weather alerts
socket.emit("joinDistrict", "Pune");
socket.on("weatherAlert", (alert) => console.log("Weather:", alert));

// Ping test
socket.emit("ping");
socket.on("pong", (data) => console.log("Pong:", data.timestamp));
```

---

## 🔐 Security Features

- JWT access + refresh tokens with HTTP-only cookies
- Token blacklist on logout
- Rate limiting: 100/15min general, 30/15min chatbot, 500/15min admin, 10/15min auth
- Helmet security headers
- MongoDB injection sanitization
- XSS protection
- CORS strict origin whitelist
- Input validation with express-validator

---

## ⏰ Cron Jobs

| Schedule | Job |
|----------|-----|
| Every hour | Check weather alerts for major districts, push via Socket.io |
| Daily 6:00 AM | Personalized tips + irrigation reminders to all farmers |
| Every Monday 8:00 AM | Weekly market price trend report |

---

## 🧪 Postman Collection Tips

1. Register: `POST /api/auth/register` → Save `accessToken`
2. Set header: `Authorization: Bearer <accessToken>`
3. Create farm: `PUT /api/users/farm`
4. Get crop prediction: `POST /api/crop/predict`
5. Test chatbot: `POST /api/chatbot/ask`
6. Simulate sensor: `POST /api/sensor/simulate`
7. Generate report: `GET /api/reports/generate?type=full`

---

## 📊 Farmer Value Metrics (Built-in)

Every prediction response includes:
- `expectedYield` (kg/acre) – exact number
- `profitEstimate` (₹/acre) – exact number
- `farmerBenefit.yieldIncreaseVsManual` – "35%"
- `farmerBenefit.costSavingINR` – ₹ amount
- `farmerBenefit.riskReductionPercent` – 20-60%

---

## 🐳 Docker (Quick Setup)

```bash
# Build
docker build -t agrovision-backend .

# Run with MongoDB
docker run -p 5000:5000 \
  -e MONGO_URI=mongodb://host.docker.internal:27017/agrovision \
  -e JWT_SECRET=your_secret_here \
  agrovision-backend
```

---

*AgroVision AI – Empowering every Indian farmer with real-time AI intelligence.*  
*IIT Capstone Project | Node.js + MongoDB + Socket.io + AI Voice Chatbot*
